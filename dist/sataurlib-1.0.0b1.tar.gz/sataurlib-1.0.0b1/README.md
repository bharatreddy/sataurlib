Tools to download, process and plot data from DMSP SSUSI and TIMED GUVI. Please refer the documentation of the respective satellites before using the data for analysis and publication.
DMSP SSUSI website - https://ssusi.jhuapl.edu/
TIMED GUVI website - http://guvitimed.jhuapl.edu/